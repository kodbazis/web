<?php

echo "php fut";