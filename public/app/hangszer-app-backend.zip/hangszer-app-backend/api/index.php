<?php

use FastRoute\Dispatcher;

require './vendor/autoload.php';

header("Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN'] ?? '*');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header('Access-Control-Allow-Headers: Origin, Pragma, Cache-control, X-Requested-With, Content-Type, Accept, Authorization');


$dispatcher = FastRoute\simpleDispatcher(function ($r) {

    $r->get('/api/instruments', function ($params, $bod) {
        header('Content-Type: application/json');
        echo file_get_contents('./instruments.json');
    });


    $r->get('/api/instruments/{id}', function ($params, $body) {
        header('Content-Type: application/json');

        $contents = file_get_contents('./instruments.json');
        $instruments = json_decode($contents, true);

        $byId = array_values(array_filter($instruments, function ($instrument) use ($params) {
            return $instrument['id'] === $params['id'];
        }));

        if (isset($byId[0])) {
            return json_encode($byId[0]);
        } else {
            http_response_code(404);
            return json_encode(['error' => 'not found']);
        }
    });

    $r->post('/api/instruments', function ($params, $body) {
        header('Content-Type: application/json');

        $content = file_get_contents('./instruments.json');
        $instruments = json_decode($content, true);

        $newItem = [
            'id' => uniqid(),
            'name' => filter_var((string)$body['name'], FILTER_SANITIZE_STRING),
            'price' => (int)$body['price'],
            'quantity' => (int)$body['quantity'],
            'imageURL' => filter_var((string)$body['imageURL'], FILTER_SANITIZE_STRING),
        ];
        $instruments[] = $newItem;
        file_put_contents('./instruments.json', json_encode($instruments));
        echo json_encode($newItem);
    });

    $r->put('/api/instruments/{id}', function ($params, $body) {
        header('Content-Type: application/json');

        $content = file_get_contents('./instruments.json');
        $instruments = json_decode($content, true);

        $index = findIndex($instruments, function ($instrument) use ($params) { 
            return $instrument['id'] === $params['id'];
        });

        if ($index === -1) {
            http_response_code(404);
            return json_encode(['error' => 'not found']);
        }

        $newItem = [
            'id' => $instruments[$index]['id'],
            'name' => filter_var((string)$body['name'], FILTER_SANITIZE_STRING),
            'price' => (int)$body['price'],
            'quantity' => (int)$body['quantity'],
            'imageURL' => filter_var((string)$body['imageURL'], FILTER_SANITIZE_STRING),
        ];
        $instruments[$index] = $newItem;
        file_put_contents('./instruments.json', json_encode($instruments));
        echo json_encode($newItem);
    });

    $r->delete('/api/instruments/{id}', function ($params, $body) {
        header('Content-Type: application/json');

        $content = file_get_contents('./instruments.json');
        $instruments = json_decode($content, true);

        $index = findIndex($instruments, function ($instrument) use ($params) { 
            return $instrument['id'] === $params['id'];
        });

        if ($index === -1) {
            http_response_code(404);
            return json_encode(['error' => 'not found']);
        }

        array_splice($instruments, $index, 1);
        file_put_contents('./instruments.json', json_encode($instruments));
        echo json_encode(['id' => $params['id']]);
    });


    try {
    } catch (Error $e) {
        var_dump($e->getMessage());
        http_response_code(500);
        header("Content-Type: application/json");
        echo '{"error": "server error"}';
        exit;
    }
});

switchRoute($dispatcher->dispatch($_SERVER['REQUEST_METHOD'], parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)), $conn);

function switchRoute(array $routeInfo)
{
    switch ($routeInfo[0]) {
        case Dispatcher::NOT_FOUND:
            if (method_exists('\Kodbazis\Router', 'registerNotFoundRoute')) {
                (new \Kodbazis\Router())->registerNotFoundRoute($conn);
            } else {
                echo json_encode(["error" => "not found"]);
            }
            break;
        case Dispatcher::METHOD_NOT_ALLOWED:
            echo json_encode(["error" => "method not allowed. allowed methods: " . implode(", ", $routeInfo[1])]);
            break;
        case Dispatcher::FOUND:
            parse_str($_SERVER['QUERY_STRING'], $query);
            $data = json_decode(file_get_contents('php://input'), true);
            try {
                echo call_user_func($routeInfo[1], $routeInfo[2], $data);
            } catch (Exception $err) {
                http_response_code(401);
                echo json_encode($err);
                exit;
            } finally {
            }
            break;
    }
}

function findIndex($elements, $fn)
{
    $ret = -1;
    foreach ($elements as $i => $element) {
        if ($fn($element)) {
            return $i;
        }
    }
    return $ret;
}

